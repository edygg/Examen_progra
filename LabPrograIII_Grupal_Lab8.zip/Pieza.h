#ifndef PIEZA_H
#define PIEZA_H
#include "Posicion.h"
#include "Enumeracion.h"

class Pieza {
protected:
	ENUM_COLOR color;
	ENUM_PIEZA tipo;
public:
	Pieza (ENUM_COLOR = NULO);	
	virtual bool esMovimientoValido(Posicion*, Posicion*);
	virtual void imprimir();
	~Pieza();
	void setTipo(ENUM_PIEZA);
};

#endif
