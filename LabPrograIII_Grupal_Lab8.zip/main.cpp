#include "Posicion.h"
#include "Ajedrez.h"

#include <iostream>
#include <string>
using namespace std;

bool validarEntrada(int);

int main(int argc, char *argv[])
{
    int opcion;
    string jugador1, jugador2;
    string jugadorActual = jugador1;

    do
    {
        Ajedrez ajedrez();

        do
        {
            int x1, x2, y1, y2;

            cout << "Juagador: " << jugadorActual;

            cout << "Ingrese x(Origen):";
            cin >> x1;

            cout << "Ingrese y(Origen):";
            cin >> y1;

            cout << "Ingrese x(Destino):";
            cin >> x2;

            cout << "Ingrese y(Destino):";
            cin >> y2;

            Posicion p1(x1, y1), p2(x2, y2);

        } while (!ajedrez.moverPieza(&p1, &p2));

        jugadorActual = (jugadorActual == jugador1 ? jugador2, jugador1);

        cout << "\n\nDesea salir: " << endl;
        cin >> salir;

    } while (opcion != 1);

    return 0;
}
