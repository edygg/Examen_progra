#include "Ajedrez.h"
#include "Torre.h"
#include "Caballo.h"
#include "rey.h"
#include "alfil.h"
#include "Reina.h"
#include "Peon.h"
#include <iostream>
using namespace std;

Ajedrez::Ajedrez() {
	inicializarTablero();
}

void Ajedrez::inicializarTablero() {
	for (int i = 0; i < 8; i++) {
		for (int j = 0; j < 8; j++) {
			tablero[i][j] = 0;	
		}	
	}
	
	tablero[0][0] = new Torre(BLANCA);	
	tablero[0][1] = new Caballo(BLANCA);
	tablero[0][2] = new Alfil(BLANCA);
	tablero[0][3] = new Reina(BLANCA);
	tablero[0][4] = new rey(BLANCA);
	tablero[0][5] = new Alfil(BLANCA);
	tablero[0][6] = new Caballo(BLANCA);
	tablero[0][7] = new Torre(BLANCA);

	tablero[7][0] = new Torre(BLANCA);	
	tablero[7][1] = new Caballo(BLANCA);
	tablero[7][2] = new Alfil(BLANCA);
	tablero[7][4] = new Reina(BLANCA);
	tablero[7][3] = new rey(BLANCA);
	tablero[7][5] = new Alfil(BLANCA);
	tablero[7][6] = new Caballo(BLANCA);
	tablero[7][7] = new Torre(BLANCA);

	for (int i = 0; i < 8; i++) {
		tablero[1][i] = new Peon(BLANCA);
		tablero[6][i] = new Peon(NEGRO);
	}

}



Ajedrez::~Ajedrez() {
	for (int i = 0; i < 8; i++) {
		for (int j = 0; j < 8; j++) {
			delete tablero[i][j];	
		}	
	}	
}

void Ajedrez::imprimir() {
	for (int i = 0; i < 8; i++) {
		for (int j = 0; j < 8; j++) {
			Pieza* tmp = tablero[i][j];
			tmp->imprimir();
			cout << " "; 
		}

		cout << endl;
	}
}
