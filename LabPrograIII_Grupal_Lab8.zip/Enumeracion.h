#ifndef ENUMERACION_H
#define ENUMERACION_H

//definicion de enumeracion de tipo enum
enum ENUM_COLOR {NEGRO,BLANCA, NULO};
enum ENUM_PIEZA {VACIA, TORRE,ALFIL,CABALLO,REINA,REY,PEON};

#endif
