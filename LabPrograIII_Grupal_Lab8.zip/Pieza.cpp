#include "Pieza.h"

Pieza::Pieza(ENUM_COLOR c) {
	this->color = c;
}

void Pieza::setTipo(ENUM_PIEZA t) {
	this->tipo = t;
}

Pieza::~Pieza() {

}

bool Pieza::esMovimientoValido(Posicion* origen, Posicion* destino) {}
void Pieza::imprimir() {}